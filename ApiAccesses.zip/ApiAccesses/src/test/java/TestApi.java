import apiAccess.Service.AccessService;
import apiAccess.model.UserResource;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;

public class TestApi {


    @Test
    public void testAddUser() throws IOException {
        AccessService accessService = new AccessService();
        UserResource resource = new UserResource();
        resource.setUserId(123456);
        resource.setEndpoint(Arrays.asList("resourceA"));
        String token = "eyJ1c2VySWQiOjEyMzQ1NiwiYWNjb3VudE5hbWUiOiAieGlhb3BhbmciLCJyb2xlIjogImFkbWluIn0=";
        String result = accessService.addUser(resource,token);
        System.out.println(result);
    }

    @Test
    public void testGetResource() throws IOException {
        AccessService accessService = new AccessService();
        String token = "eyJ1c2VySWQiOjEyMzQ1NiwiYWNjb3VudE5hbWUiOiAieGlhb3BhbmciLCJyb2xlIjogInVzZXIifQ==";
        String result = accessService.getResource("resourceA",token);
        System.out.println(result);
    }
}
