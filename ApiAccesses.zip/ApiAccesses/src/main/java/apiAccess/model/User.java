package apiAccess.model;

import lombok.Data;

@Data
public class User {
    private int userId;
    private String accountName;
    private String role;
}
