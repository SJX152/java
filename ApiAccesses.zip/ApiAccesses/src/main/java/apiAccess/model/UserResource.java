package apiAccess.model;

import lombok.Data;

import java.util.List;

@Data
public class UserResource {
    private int userId;
    private List<String> endpoint;
}
