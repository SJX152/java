package apiAccess.Service;

import apiAccess.model.User;
import apiAccess.model.UserResource;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

@Component
public class AccessService {

    public String addUser(UserResource userResource, String token) throws IOException {
        if (userResource == null || userResource.getEndpoint()==null || userResource.getEndpoint().isEmpty()) {
            return "error resource";
        }
        String decodeToken = new String(Base64.getDecoder().decode(token));
        User user = JSONObject.parseObject(decodeToken, User.class);
        if (!checkAccessForAdd(user)) {
            return "error access";
        }
        File file = new File("src/main/resources/Resource.json");
        String jsonString = FileUtils.readFileToString(file, "UTF-8");
        JSONArray array = JSON.parseArray(jsonString);
        if (array == null) {
            JSONArray resources = new JSONArray();
            resources.add(JSON.toJSONString(userResource));
            FileUtils.writeStringToFile(file, JSON.toJSONString(resources), "UTF-8");
            return "add success";
        } else {
            UserResource resource = array.stream().map(t -> JSON.parseObject(t.toString(), UserResource.class))
                    .filter(s -> s.getUserId() == userResource.getUserId()).findFirst().orElse(null);
            if (resource == null) {
                array.add(JSON.toJSONString(userResource));
            } else {
                for (String point : userResource.getEndpoint()) {
                    if (!resource.getEndpoint().contains(point)) {
                        resource.getEndpoint().add(point);
                    }
                }
            }
            FileUtils.writeStringToFile(file, JSON.toJSONString(array), "UTF-8");
            return "add success";
        }
    }

    public String getResource(String name, String token) throws IOException {
        String decodeToken = new String(Base64.getDecoder().decode(token));
        User user = JSONObject.parseObject(decodeToken, User.class);
        UserResource resource = checkAccessForGetResource(user);
        if (resource == null) {
            return "access error";
        } else {
            if (resource.getEndpoint() != null && resource.getEndpoint().contains(name)) {
                return "get resource success";
            } else {
                return "get resource fail";
            }
        }
    }

    public boolean checkAccessForAdd(User user) {
        if (user == null) {
            return false;
        }
        return "admin".equals(user.getRole());
    }

    public UserResource checkAccessForGetResource(User user) throws IOException {
        if (user == null || !"user".equals(user.getRole())) {
            return null;
        }
        File file = new File("src/main/resources/Resource.json");
        String jsonString = FileUtils.readFileToString(file, "UTF-8");
        JSONArray array = JSON.parseArray(jsonString);
        return array.stream().map(t -> JSON.parseObject(t.toString(), UserResource.class))
                .filter(s -> s.getUserId() == user.getUserId()).findFirst().orElse(null);
    }

}