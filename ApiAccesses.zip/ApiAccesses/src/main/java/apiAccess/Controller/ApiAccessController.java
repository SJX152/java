package apiAccess.Controller;

import apiAccess.Service.AccessService;
import apiAccess.model.UserResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
public class ApiAccessController {

    @Autowired
    private AccessService accessService;

    @PostMapping("/admin/addUser")
    public ResponseEntity<String> addUser(
            @RequestHeader(value = "auth", required = false) String token,
            @RequestBody UserResource userResource
    ) {
        String result = null;
        try {
            result = accessService.addUser(userResource, token);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.of(Optional.of("add fail"));
        }
    }

    @GetMapping("/user/{resourceName}")
    public ResponseEntity<String> getResource(
            @RequestHeader(value = "auth", required = false) String token,
            @PathVariable String resourceName
    ) {
        String result = null;
        try {
            result = accessService.getResource(resourceName, token);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.of(Optional.of("get fail"));
        }
    }
}
